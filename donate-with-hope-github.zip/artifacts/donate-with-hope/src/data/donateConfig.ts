export type Campaign = {
  slug: string;
  path: string;
  title: string;
  badge: string;
  description: string;
  cta: string;
  image: string;
  imageAlt: string;
  accent: string;
  amounts: { value: number; label: string }[];
  checkoutUrl: string;
};

export const campaigns: Campaign[] = [
  {
    slug: 'food',
    path: '/campaigns/food',
    title: 'Food for a Month',
    badge: '100% Zakat Eligible',
    description: 'Food insecurity can place enormous pressure on families already facing difficult circumstances. This campaign supports the provision of essential food supplies to families who need reliable access to meals.',
    cta: 'Donate to food campaign',
    image: '/assets/campaigns/food/cover.png',
    imageAlt: 'Hands arranging staple food provisions in a woven basket',
    accent: 'sand',
    amounts: [{ value: 50, label: 'Food for 14 Days' }, { value: 100, label: 'Food for One Family for One Month' }, { value: 200, label: 'Food for Two Families for One Month' }],
    checkoutUrl: '',
  },
  {
    slug: 'student-support',
    path: '/campaigns/student-support',
    title: 'Student Support',
    badge: '100% Sadaqah',
    description: 'Education can open doors to opportunity. This campaign helps students facing financial barriers continue their university education.',
    cta: 'Support a student',
    image: '/assets/campaigns/student-support/cover.png',
    imageAlt: 'Student studying at a library desk with books and a laptop',
    accent: 'ochre',
    amounts: [{ value: 150, label: 'Half Semester University Fee' }, { value: 300, label: 'Full Semester University Fee' }, { value: 600, label: 'Support Two Students' }],
    checkoutUrl: '',
  },
  {
    slug: 'medical',
    path: '/campaigns/medical',
    title: 'Medical Support',
    badge: 'Zakat & Sadaqah Accepted',
    description: "Access to medical care can become difficult when treatment and essential medicines are beyond a family's financial means. This campaign supports people facing urgent healthcare needs.",
    cta: 'Support medical care',
    image: '/assets/campaigns/medical/cover.png',
    imageAlt: "Clinician's hands preparing essential medicine at a clinic table",
    accent: 'sage',
    amounts: [{ value: 50, label: 'Essential Medicines' }, { value: 150, label: 'Medical Treatment Support' }, { value: 500, label: 'Critical Medical Assistance' }],
    checkoutUrl: '',
  },
  {
    slug: 'emergency',
    path: '/campaigns/emergency',
    title: 'Emergency Appeals',
    badge: 'Zakat & Sadaqah Accepted',
    description: 'When emergencies strike, timely assistance can help families meet immediate needs. This campaign supports emergency relief and essential assistance when circumstances demand a rapid response.',
    cta: 'Help in an emergency',
    image: '/assets/campaigns/emergency/cover.png',
    imageAlt: 'A relief kit and folded blanket being handed across a doorway',
    accent: 'clay',
    amounts: [{ value: 50, label: 'Emergency Essentials' }, { value: 100, label: 'Family Emergency Support' }, { value: 300, label: 'Emergency Relief Package' }, { value: 450, label: 'Extended Emergency Support' }],
    checkoutUrl: '',
  },
];

export const getCampaign = (slug?: string) => campaigns.find((campaign) => campaign.slug === slug);