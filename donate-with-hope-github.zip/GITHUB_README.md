# Donate With Hope Foundation

Premium, responsive charity website for Donate With Hope Foundation.

## Included

- React + Vite frontend
- Responsive homepage and campaign pages
- Food for a Month, Student Support, Medical Support, and Emergency Appeals campaigns
- Uploaded campaign artwork and logo assets
- Honest placeholder states for unverified impact data
- Shopify checkout integration points
- Accessibility and SEO basics

## Run locally

Requirements: Node.js 20+ and pnpm.

```bash
pnpm install
pnpm --filter @workspace/donate-with-hope run dev
```

The Replit workflow supplies `PORT` and `BASE_PATH`. For a local Vite run, set them manually if needed:

```bash
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/donate-with-hope run dev
```

## Build and check

```bash
pnpm --filter @workspace/donate-with-hope run typecheck
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/donate-with-hope run build
```

## Campaign content and images

- Campaign data and donation options: `artifacts/donate-with-hope/src/data/donateConfig.ts`
- Shopify destination configuration: `artifacts/donate-with-hope/public/config/donations.json`
- Logo: `artifacts/donate-with-hope/public/assets/logo/`
- Campaign artwork: `artifacts/donate-with-hope/public/assets/campaigns/`

Replace the checkout URLs only when real Shopify destinations are available. Empty checkout URLs intentionally show “Donation checkout coming soon.”.

## GitHub

After extracting this bundle:

```bash
git init
git add .
git commit -m "Initial Donate With Hope Foundation website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Do not commit secrets, `.env` files, `node_modules`, or build output.